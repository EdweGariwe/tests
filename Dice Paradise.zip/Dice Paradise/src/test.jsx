import React from "react";
import "./test.css";

const test = () => {
  return (
    <div className="main-wrapper">
      <div className="container">
        <div className="background-image">
            
        </div>
      </div>
    </div>
  );
};

export default test;
